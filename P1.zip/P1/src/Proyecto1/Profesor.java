package Proyecto1;

import java.util.ArrayList;
import java.util.List;

public class Profesor extends Usuario {
    private int idProfesor;
    private List<LearningPath> learningPaths;

    public Profesor(String nombreUsuario, String contrasena, String correo, int idProfesor) {
        super(nombreUsuario, contrasena, correo);
        this.idProfesor = idProfesor;
        this.learningPaths = new ArrayList<>();
    }

    public int getIdProfesor() {
        return idProfesor;
    }

    public void setIdProfesor(int idProfesor) {
        this.idProfesor = idProfesor;
    }

    public List<LearningPath> getLearningPaths() {
        return learningPaths;
    }

    public void crearLearningPath(LearningPath lp) {
        learningPaths.add(lp);
    }

    public void modificarLearningPath(LearningPath lp, String nuevoTitulo, String nuevaDescripcion) {
        lp.setTitulo(nuevoTitulo);
        lp.setDescripcion(nuevaDescripcion);
    }
    public void calificarLearningPath(LearningPath lp, int calificacion) {
        lp.calificar(calificacion);
        System.out.println("Learning Path calificado con éxito.");
    }
}

